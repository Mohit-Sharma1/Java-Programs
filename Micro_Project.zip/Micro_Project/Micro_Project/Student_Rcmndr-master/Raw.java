public class Raw extends Exception {

        public Raw(String msg)
        {
            super(msg);
        }


}
