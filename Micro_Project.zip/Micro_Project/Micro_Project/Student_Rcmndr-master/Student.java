public class Student {
    String name;
    float arr[] = new float[5];
}
